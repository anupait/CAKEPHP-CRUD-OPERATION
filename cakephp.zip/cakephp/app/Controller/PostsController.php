<?php

App::uses('AppController', 'Controller');
class PostsController extends AppController {

	public $name = 'Posts';

	public $helpers = array('Html', 'Session','form');
	
	public function index()
	{
	
	 $this->set('postList',$this->Post->find('all'));
	
	}
	
	
	public function add()
	{
	if(!empty($this->data))
	{
	    if($this->Post->save($this->data))
		   {
		        $this->Session->setFlash('Your Post data has been saved.');
                $this->redirect(array('action' => 'index'));
		   }
	}
	}
	
	
	public function delete($id)
	{
	
	$this->Post->delete($id);
	$this->Session->setFlash('Post has been deleted successfully');
	$this->redirect(array('action'=>'index'));
	
	}
	
	
	public function edit($id=null)
	{
	
	
        $this->Post->id = $id;
        if (empty($this->data))
        {
            $this->data = $this->Post->read();
        }
        else 
        {
            if ($this->Post->save($this->data)) 
            {
                $this->Session->setFlash('Your Post with id: '.$id.' has been updated.');
                $this->redirect(array('action' => 'index'));
            }
        }
    
	
	}
	
	
	
}
