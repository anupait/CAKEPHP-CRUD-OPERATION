<?php


App::uses('Model', 'Model');

class Post extends Model {

var $name='Post';

}
